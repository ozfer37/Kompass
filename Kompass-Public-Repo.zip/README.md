<p align="center">
  <img src="kompass/assets/images/logo.png" alt="KOMPASS Logo" width="110" />
</p>

<h1 align="center">KOMPASS</h1>

<p align="center">
  <strong>Intelligent Tour Coordination and Management Mobile Application</strong>
</p>

<p align="center">
  <a href="https://flutter.dev"><img src="https://img.shields.io/badge/Flutter-v3.8+-02569B?logo=flutter&logoColor=white" alt="Flutter" /></a>
  <a href="https://dart.dev"><img src="https://img.shields.io/badge/Dart-v3.8+-0175C2?logo=dart&logoColor=white" alt="Dart" /></a>
  <a href="https://firebase.google.com"><img src="https://img.shields.io/badge/Firebase-Auth%20%7C%20Firestore%20%7C%20FCM-FFCA28?logo=firebase&logoColor=black" alt="Firebase" /></a>
  <a href="https://github.com/MohdFer/Kompass/releases"><img src="https://img.shields.io/badge/Release-v1.0.0--beta.1-brightgreen" alt="Beta Release" /></a>
  <a href="https://github.com/MohdFer/Kompass/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-MIT-blue.svg" alt="License" /></a>
</p>

---

## 📌 Overview

**KOMPASS** is a smart, unified tour management and group coordination mobile platform built with **Flutter** and **Firebase**. 

Managing group tours typically forces guides and participants across disconnected chat apps, paper rosters, and GPS tools. KOMPASS consolidates tour itineraries, digital attendance, consent-based real-time member tracking, group communication, and emergency SOS alerts into a single cohesive experience. 

Inspired by academic research into large-scale group movement (such as pilgrim safety during Hajj), KOMPASS is designed to scale from standard group excursions to complex, high-density crowd environments.

---

## ✨ Key Features

### 👤 Role-Based Portals
- **Tour Guides / Organizers:** Create and administer tours, manage schedules, monitor attendee locations, broadcast announcements, and oversee check-ins.
- **Tour Participants:** Access itineraries, view meeting points on interactive maps, share location with consent, communicate with guides, and trigger SOS.

### 📋 Tour & Itinerary Management
- Digital scheduling with timeline milestones, checkpoints, and designated gathering points.
- Real-time updates pushed instantly to all group members.

### 📍 Live Interactive Map & Geofencing
- Powered by **OpenStreetMap** and `flutter_map` for cross-platform mapping without vendor lock-in.
- Consent-based participant location visualization with privacy controls.
- Proximity alerts and geofencing around scheduled meeting hubs.

### 🎟️ Smart Digital Attendance
- Dynamic **QR Code scanning** (`mobile_scanner` / `qr_flutter`) for rapid, paperless checkpoint check-ins.
- Manual verification fallback for guides when network or camera conditions are constrained.

### 💬 Unified Group Communication
- Real-time in-app tour chat rooms and broadcast notices.
- Push notifications via **Firebase Cloud Messaging (FCM)** for critical tour alerts and schedule changes.

### 🚨 Emergency SOS System
- One-tap SOS trigger alerting guides immediately with the participant's exact GPS coordinates and status.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend Framework** | [Flutter](https://flutter.dev) (Dart SDK `^3.8.0`) |
| **State Management** | [Riverpod](https://riverpod.dev) (`flutter_riverpod`, `riverpod_annotation`) |
| **Backend & Cloud** | [Firebase](https://firebase.google.com) (Auth, Cloud Firestore, Cloud Storage, Cloud Messaging) |
| **Maps & Geolocation** | OpenStreetMap, `flutter_map`, `latlong2`, `geolocator`, `geocoding` |
| **Hardware & Scanning** | `mobile_scanner`, `qr_flutter` |
| **Local Persistence** | `hive`, `shared_preferences` |
| **Serverless Logic** | Firebase Cloud Functions (TypeScript / Node.js) |

---

## 🗺️ Roadmap & Development Phases

```mermaid
flowchart LR
    A["Phase 1: Core Platform<br/>(Current Beta)"] --> B["Phase 2: Offline & Mesh<br/>(In Progress)"]
    B --> C["Phase 3: AI & Predictions<br/>(Planned)"]
```

- **Phase 1 (Core Platform — Current Beta):**
  - [x] Firebase Authentication (Google Sign-In + Email/Password)
  - [x] Tour creation, itinerary, and member management
  - [x] QR code & manual digital attendance
  - [x] Live GPS tracking and map visualization
  - [x] Real-time messaging and emergency SOS
- **Phase 2 (Offline Resilience & Mesh):**
  - [ ] Custom hybrid geofencing (Haversine & Ray Casting polygonal algorithms)
  - [ ] Offline Bluetooth Low Energy (BLE) Mesh communication (inspired by BitChat)
  - [ ] WebRTC 1-to-1 and group voice communication
  - [ ] Offline-first data synchronization
- **Phase 3 (Predictive AI & Intelligence):**
  - [ ] Crowd density prediction models (LSTM / STGCN)
  - [ ] Multilingual AI tour assistant (Gemini API & on-device DistilBERT)
  - [ ] Trajectory prediction for lost participants
  - [ ] Real-time weather and environmental safety risk alerts

---

## 📂 Project Structure

```text
Kompass/
├── functions/             # Firebase Cloud Functions backend
├── kompass/               # Flutter mobile application
│   ├── assets/            # App icons, fonts, and brand assets
│   ├── lib/
│   │   ├── core/          # App constants, themes, and global utilities
│   │   ├── features/      # Feature modules (auth, tours, map, attendance, chat, sos)
│   │   ├── models/        # Data models and serializable entities
│   │   ├── services/      # Firebase, location, and background services
│   │   └── main.dart      # Application entrypoint
│   └── pubspec.yaml       # Flutter dependencies & metadata
├── firebase.json          # Firebase project configuration
├── PRD.md                 # Product Requirements Document
├── TRD.md                 # Technical Requirements Document
└── HOW_TO_RUN.md          # Step-by-step local execution guide
```

---

## 🚀 Getting Started

### Prerequisites

Ensure you have the following installed on your machine:
1. **[Git](https://git-scm.com/downloads)**
2. **[Flutter SDK](https://docs.flutter.dev/get-started/install)** (`^3.8.0`) — verify via `flutter doctor`
3. **IDE**: VS Code (with Flutter extension) or Android Studio
4. **Target Platform**: Google Chrome (for Web testing) or an Android Emulator / physical Android device

### Installation & Run

1. **Clone the repository:**
   ```bash
   git clone https://github.com/MohdFer/Kompass.git
   cd Kompass/kompass
   ```

2. **Install dependencies:**
   ```bash
   flutter pub get
   ```

3. **Run on Web (Google Chrome):**
   ```bash
   flutter run -d chrome
   ```

4. **Run on Android:**
   Connect your Android device or start an emulator, then execute:
   ```bash
   flutter run
   ```

> **Note on Configuration:** Sensitive API keys and service credentials have been stripped for public repository security. Run `flutterfire configure` inside `kompass/` to generate your own `firebase_options.dart` and `google-services.json`, and pass ZEGOCloud credentials via `--dart-define=ZEGO_APP_ID=... --dart-define=ZEGO_APP_SIGN=...`.

---

## 🤝 Contributing

Contributions, feedback, and issue submissions are welcome!

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

This project is developed as an academic capstone and research project. Distributed under the **MIT License**. See `LICENSE` for details.

---

<p align="center">
  Built with ❤️ for safer, smarter, and seamless group journeys.
</p>
